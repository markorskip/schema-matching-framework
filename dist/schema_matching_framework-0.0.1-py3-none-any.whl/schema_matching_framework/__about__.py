# SPDX-FileCopyrightText: 2024-present markorskip <mark@efficientsoftware.io>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
